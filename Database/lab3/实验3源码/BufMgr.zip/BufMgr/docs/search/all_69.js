var searchData=
[
  ['insert',['insert',['../classbadgerdb_1_1_buf_hash_tbl.html#a92480d460ddb07e8b04ab7f99107e334',1,'badgerdb::BufHashTbl']]],
  ['insertrecord',['insertRecord',['../classbadgerdb_1_1_page.html#ad0b1e85fe7849fb767dd8c21a8053cf4',1,'badgerdb::Page']]],
  ['insufficientspaceexception',['InsufficientSpaceException',['../classbadgerdb_1_1_insufficient_space_exception.html',1,'badgerdb']]],
  ['insufficientspaceexception',['InsufficientSpaceException',['../classbadgerdb_1_1_insufficient_space_exception.html#a05ee1817c52c8bc284712fd5aef305a0',1,'badgerdb::InsufficientSpaceException']]],
  ['invalid_5fnumber',['INVALID_NUMBER',['../classbadgerdb_1_1_page.html#a785a1e756d47fb7f8f3603a3fe8ffcef',1,'badgerdb::Page']]],
  ['invalid_5fslot',['INVALID_SLOT',['../classbadgerdb_1_1_page.html#a4013fab43df72bc52931241575736353',1,'badgerdb::Page']]],
  ['invalidpageexception',['InvalidPageException',['../classbadgerdb_1_1_invalid_page_exception.html',1,'badgerdb']]],
  ['invalidpageexception',['InvalidPageException',['../classbadgerdb_1_1_invalid_page_exception.html#a95454bbb13eafd87874c0dd538cc4fa8',1,'badgerdb::InvalidPageException']]],
  ['invalidrecordexception',['InvalidRecordException',['../classbadgerdb_1_1_invalid_record_exception.html#a317a2fda3088cbf04a24189f089a68ed',1,'badgerdb::InvalidRecordException']]],
  ['invalidrecordexception',['InvalidRecordException',['../classbadgerdb_1_1_invalid_record_exception.html',1,'badgerdb']]],
  ['invalidslotexception',['InvalidSlotException',['../classbadgerdb_1_1_invalid_slot_exception.html',1,'badgerdb']]],
  ['invalidslotexception',['InvalidSlotException',['../classbadgerdb_1_1_invalid_slot_exception.html#a60f721f46b7aeacc655e1f3f0423314d',1,'badgerdb::InvalidSlotException']]],
  ['isopen',['isOpen',['../classbadgerdb_1_1_file.html#a64836156a9bb5f81d2c2c4e6f3ada24d',1,'badgerdb::File']]],
  ['item_5flength',['item_length',['../structbadgerdb_1_1_page_slot.html#a675118fb03cd9e1b35970a1f10bda9d8',1,'badgerdb::PageSlot']]],
  ['item_5foffset',['item_offset',['../structbadgerdb_1_1_page_slot.html#a81c14b0e942b0d59e6ac31667d958b79',1,'badgerdb::PageSlot']]]
];
