var searchData=
[
  ['bufpool',['bufPool',['../classbadgerdb_1_1_buf_mgr.html#aa498047fc351652d0bc7eabf6cb62ab0',1,'badgerdb::BufMgr']]]
];
