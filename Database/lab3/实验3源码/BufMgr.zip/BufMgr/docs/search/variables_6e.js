var searchData=
[
  ['name',['name',['../classbadgerdb_1_1_hash_already_present_exception.html#a3c7470b1b701e5a5a35fd98692118c47',1,'badgerdb::HashAlreadyPresentException::name()'],['../classbadgerdb_1_1_hash_not_found_exception.html#aaa19f545bf6c6c18d7907c31ed48fd89',1,'badgerdb::HashNotFoundException::name()'],['../classbadgerdb_1_1_page_not_pinned_exception.html#a927b401b56f4ae042e2ba55599898e3c',1,'badgerdb::PageNotPinnedException::name()'],['../classbadgerdb_1_1_page_pinned_exception.html#ad7e83fd94b72c492b5631749a7b74e41',1,'badgerdb::PagePinnedException::name()']]],
  ['next',['next',['../structbadgerdb_1_1hash_bucket.html#aca2ab1451a26b84317cb28f99793d43c',1,'badgerdb::hashBucket']]],
  ['next_5fpage_5fnumber',['next_page_number',['../structbadgerdb_1_1_page_header.html#a7cb8260dedb0748d3d75c4b1722dcf3c',1,'badgerdb::PageHeader']]],
  ['num_5ffree_5fpages',['num_free_pages',['../structbadgerdb_1_1_file_header.html#a07ac20f98d6aced3eb5358e0d4830abc',1,'badgerdb::FileHeader']]],
  ['num_5ffree_5fslots',['num_free_slots',['../structbadgerdb_1_1_page_header.html#a7afd8d3c6f22b25e24958ebef773175e',1,'badgerdb::PageHeader']]],
  ['num_5fpages',['num_pages',['../structbadgerdb_1_1_file_header.html#aa1cfc5220c6795868c8301cec298c8a6',1,'badgerdb::FileHeader']]],
  ['num_5fslots',['num_slots',['../structbadgerdb_1_1_page_header.html#a6c233369c611cfb617ba676e11a9d87d',1,'badgerdb::PageHeader']]]
];
